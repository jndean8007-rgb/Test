from Physics import Game
import json

def main():

    game = Game.Game(800, 600, 60, r"C:/Users/rosie/PycharmProjects/PythonProject1/Test/Learning/GEng/3d_data.json")

if __name__ == '__main__':
    main()