import pygame as pg

class Controls:
    def __init__(self, camera, bodies, renderer, game):
        self.camera = camera
        self.bodies = bodies
        self.renderer = renderer
        self.game = game

    def act(self, event):
        if event.type == pg.KEYDOWN:
            if event.key == pg.K_LEFT:
                self.camera.move([-1, 0, 0])
            elif event.key == pg.K_RIGHT:
                self.camera.move([1, 0, 0])
            elif event.key == pg.K_UP:
                self.camera.move([0, 1, 0])
            elif event.key == pg.K_DOWN:
                self.camera.move([0, -1, 0])
            elif event.key == pg.K_SPACE and self.camera.is_on():
                self.camera.vz = 5.0

        elif event.type == pg.MOUSEBUTTONDOWN and event.button == 1:
            for body in self.bodies.values():
                click_handler = getattr(body, "is_clicked", None)
                if click_handler is not None:
                    click_handler()

            #if event.button == 3:
                # bring up small menu

        #elif event.type == pg.MOUSEBUTTONUP:
            #if event.button == 3:
                # dissapate small menu for object selection

    def init_act(self, event):
        if event.type == pg.KEYDOWN:
            #if event.key == pg.K_UP:
            #up through options
            #if event.key == pg.K_DOWN:
            #scroll downwards through options
            if event.key == pg.K_SPACE:
                if self.renderer.init_button == 'is_start':
                    self.game.run()
            # Select option
                #elif init button something else